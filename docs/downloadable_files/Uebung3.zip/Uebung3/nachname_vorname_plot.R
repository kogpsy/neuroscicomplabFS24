# Code innerhalb der folgenden 2 Linien darf nicht verändert werden
# --------------------------------------------------------------------------------------
library(tidyverse)
d = read_csv('data/dataset_stroop_clean.csv')
# --------------------------------------------------------------------------------------

# Beginnen Sie hier mit Ihrem Code:

p = d |>
    ggplot(...) +
    ...
p
